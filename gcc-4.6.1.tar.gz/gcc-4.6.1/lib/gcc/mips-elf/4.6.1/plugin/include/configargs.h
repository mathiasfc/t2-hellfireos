/* Generated automatically. */
static const char configuration_arguments[] = "/home/sergio/temp/build_toolchain/source/gcc-4.6.1/configure --prefix=/usr/local/mips/gcc-4.6.1 --target=mips-elf --with-gnu-as --with-gnu-ld --enable-languages=c --with-newlib";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "synci", "no-synci" } };
